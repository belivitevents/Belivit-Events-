BELIVIT EVENTS WEBSITE

Upload all files to your hosting public_html folder.
Open index.html to preview locally.
Before publishing, confirm phone/WhatsApp and add Google Maps link.
